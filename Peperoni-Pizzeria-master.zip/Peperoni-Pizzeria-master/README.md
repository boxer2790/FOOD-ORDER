# Peperoni-Pizzeria
<b>Restaurant Management System | NetBeans &amp; MySQL</b>

This Repository consist of following :

-   PEPERONI_PIZZERIA which consists of Main Application ( All the Files for NetBeans Project )<br>
    -   Source code with proper comments for Better Instructions
-   SCREENSHOTS of Appilcation
    -   Welcome
    -   Home
    -   About Us
    -   Contact Us
    -   Login
    -   Admin
    -   Stock Management
    -   Order
    -   Feedback
-   Detailed REPORT of Project
    -   Objective & Task
    -   Features Available
    -   Database & Tables
    -   User Manual

<b>Online MYSQL Databse Connection Details</b><br><br>
SERVER - db4free.net<br>
PORT NO - 3306<br>
DATABASE – peperonipizzeria<br>
USERNAME - curiorimor<br>
PASSWORD - curiorimor<br>
<br>
<b>Login Credentials ( Netbeans )</b><br>
USERNAME - peperoni<br>
PASSWORD - pizzeria
